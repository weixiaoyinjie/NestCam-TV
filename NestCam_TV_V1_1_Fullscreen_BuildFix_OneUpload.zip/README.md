# NestCam TV V1.1 — 全屏探头 / 下翻设置版

独立 Google TV / Android TV Nest 探头查看 App。只生成 TV APK，**不需要安装/修改原手机或 Wear OS App**。
此版本基于用户提供的 NestCam V1.1 代码和前一版 NestCam TV V1.0 源码进行 UI 调整；继续使用原 Nest SDM API + WebRTC。Android TV 不能直接使用手表 Data Layer，电视使用自己的 Google Nest 授权。

## 两屏布局

**第一屏：全屏直播**

- App 打开直接是摄像头视频，占满电视屏幕，没有常驻标题、按钮或工具栏。
- 默认 `铺满屏幕`，会在摄像头原始比例不等于电视比例时裁掉少量边缘；可在下方设置切成 `完整画面`（留黑边，不裁剪）。
- 首次没有 Google 授权、设备读取失败或直播停掉时，才显示必要提示；直播成功后不显示提示文字。
- 恢复上次选择的探头，授权有效时自动连接，继续使用 Google Nest WEB_RTC 直播与云端会话续期。

**第二屏：设置和控制（从底部上翻）**

- 按遥控器 **↓**：下翻打开设置和控制页。
- 按 **返回**：关闭设置，回到全屏直播，**不会停止直播**。
- 可切换前后探头、播放、停止、重连、刷新 Nest 摄像头列表、切换画面裁剪模式。
- OAuth Client ID/Secret 配置、扫码授权、输入授权回调 code、清除电视本机授权。

遥控器首页快捷键：

| 按键 | 操作 |
|---|---|
| ↓ | 下翻打开设置页 |
| ← / → | 上一个 / 下一个探头 |
| 确认键 | 短暂显示探头名称和直播状态，自动消失 |
| 播放 / 暂停媒体键 | 播放 / 停止 |
| TV 遥控器返回键 | 在设置页返回全屏；首页返回交由系统处理 |

## 首次设置与隐私

1. 安装 APK 后打开，首页出现 `按 ↓ 进入设置`。
2. 按 ↓，在设置页输入你现有 Google Cloud OAuth Client ID 和 Client Secret，二者只保存于电视本地的加密存储，不预置于源代码中。
3. 选择 `手机扫码授权`，手机打开 Google Nest 授权页面并同意权限。
4. 将手机浏览器最终回调地址（包含 `code=`）或授权 code 输入电视 `输入回调 code`。电视使用原 Google Device Access 项目 ID 发现支持 WEB_RTC 的摄像头。
5. 授权成功后自动尝试开始直播，以后打开电视 App 自动恢复上次探头。按返回回到全屏。

限制：需要真实 Nest Device Access 注册及对应 Google Cloud OAuth 凭据，`redirect_uri` 必须与现有项目设置一致（本源码沿用 `https://www.google.com`）。摄像头必须支持官方 Google Nest SDM `WEB_RTC`；不支持 RTSP/HLS 摄像头。授权不通过手机 App 转发，手表/手机 APK 不会被修改。

## 上传 GitHub 自动编译 TV APK

### 方式 A（推荐）

1. GitHub 新建空仓库（建议 `NestCam-TV`）。
2. 在电脑解压 `NestCam_TV_V1_1_Fullscreen_OneUpload.zip`，把所有文件和文件夹（含隐藏 `.github` 目录）上传至仓库根目录。不要多套一层目录。
3. 打开 GitHub → Actions → `Build NestCam TV V1.1 Fullscreen APK` → `Run workflow`。
4. 在该次 Actions 运行页面下载 Artifact：`NestCam-TV-V1.1-Fullscreen-APK`，里面是 `tv-debug.apk`，安装到 Google TV。

### 方式 B（不解压，只上传两个文件）

1. 仓库根目录上传 `NestCam_TV_V1_1_Fullscreen_OneUpload.zip`。
2. 把单独提供的 `NestCam_TV_V1_1_Build.yml` **重命名为** `build.yml`，上传到仓库 `.github/workflows/build.yml`。GitHub 的工作流不能只存在 ZIP 内。
3. Actions 工作流自动解压 ZIP 并运行 `gradle :tv:assembleDebug`。

输出：只编译 `:tv` Android TV APK，应用包名 `com.nestcam.tv`，版本 `1.1-tv-fullscreen`。不会覆盖原手机或手表 App。

构建环境：Java 17 / Gradle 8.11.1 / AGP 8.9.2 / Android SDK 35 / WebRTC `150.7871.08`。

**测试状态：源码结构和打包可验证，但当前没有 Android SDK/Gradle 执行环境，未本地编译 APK，也未完成真机连接、遥控器以及 Google Nest 登录/播放验证。请以 GitHub Actions 日志和电视实际测试结果为准。**


## GitHub Android SDK 初始化失败修复（2026-11-20）

- GitHub Actions 报错在 `Set up Android SDK`：原工作流使用 `android-actions/setup-android@v3`，先下载 SDK 命令行工具，在远程仓库读取阶段可能失败。
- BuildFix 工作流改为检测并使用 `ubuntu-24.04` runner 预装的 Android SDK、API 35 与 Build Tools 35.0.0；仅在缺少组件时尝试安装。
- 仅替换 `.github/workflows/build.yml` 就能修复已有完整源码仓库的此阶段，无须重传 Java/布局文件。
- 如果仓库仅上传 ZIP，请上传 **NestCam_TV_V1_1_Fullscreen_BuildFix_OneUpload.zip** 至仓库根目录，并同时更新 `.github/workflows/build.yml`（单独提供的 BuildFix.yml，重命名为 build.yml）。
- ZIP 内含已更新工作流，但 GitHub Actions **无法直接执行压缩包内部** 的 workflow，工作流必须存在于 GitHub 仓库的 `.github/workflows/build.yml` 路径。
- 原版 App 仍为 `NestCam TV V1.1 Fullscreen`，仅修改构建配置；没有修改电视上全屏直播/按 ↓ 进入设置的功能。
- 本地仅检查了源码包完整性和 YAML 结构，仍须 GitHub Actions 运行与 Google TV 实机验证。
