package com.nestcam.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.nestcam.watch8.shared.RtcViewer;

import org.json.JSONArray;
import org.json.JSONObject;
import org.webrtc.RendererCommon;
import org.webrtc.SurfaceViewRenderer;

import java.time.Instant;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * TV-only Nest camera viewer.
 * Screen 1 is borderless video: DOWN opens the second (settings) screen.
 * Settings slide up from below the TV viewport; BACK returns to the live image.
 * No mobile or watch application is required to render on the television.
 */
public final class TvActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ArrayList<Camera> cameras = new ArrayList<>();
    private NestApi api;
    private RtcViewer rtc;
    private SurfaceViewRenderer surface;
    private FrameLayout root;
    private ScrollView settingsPage;
    private TextView cameraName, statusText, emptyHint, displayModeLabel, infoOverlay;
    private Button configButton, firstSettingsButton;
    private boolean settingsOpen = false;
    private boolean fillVideo = true;
    private int chosen = -1;
    private boolean active = false;
    private boolean refreshing = false;
    private boolean foreground = false;
    private long generation = 0;
    private String mediaSession = "", streamingDevice = "";
    private Runnable extension;
    private Runnable hideInfo;

    private static final class Camera {
        final String name, id;
        Camera(String name, String id) { this.name = name; this.id = id; }
    }

    private int dp(float value) {
        return (int) (getResources().getDisplayMetrics().density * value + 0.5f);
    }

    private TextView text(String value, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private Button makeButton(String title, LinearLayout parent, Runnable action) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(title);
        b.setTextSize(16);
        b.setTextColor(Color.WHITE);
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setBackgroundTintList(null);
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_focused}, background(0xff216fb3, 11));
        states.addState(new int[]{android.R.attr.state_pressed}, background(0xff216fb3, 11));
        states.addState(new int[]{}, background(0xff223349, 11));
        b.setBackground(states);
        b.setFocusable(true);
        b.setFocusableInTouchMode(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(54), 1);
        p.leftMargin = dp(6);
        p.rightMargin = dp(6);
        parent.addView(b, p);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private LinearLayout row(LinearLayout parent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(64));
        parent.addView(row, lp);
        return row;
    }

    private void fullScreen() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        api = new NestApi(this);
        fillVideo = getPreferences(MODE_PRIVATE).getBoolean("fill_video", true);
        buildUi();
        loadCached();
    }

    private void buildUi() {
        fullScreen();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        setContentView(root);

        // PAGE ONE: true edge-to-edge camera picture, no permanent toolbar/header/buttons.
        surface = new SurfaceViewRenderer(this);
        surface.setFocusable(false);
        root.addView(surface, new FrameLayout.LayoutParams(-1, -1));

        emptyHint = text("", 21, 0xffdae7f7);
        emptyHint.setGravity(Gravity.CENTER);
        emptyHint.setPadding(dp(45), dp(30), dp(45), dp(30));
        emptyHint.setBackground(background(0xdd101b29, 16));
        FrameLayout.LayoutParams hintLp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        hintLp.leftMargin = dp(70);
        hintLp.rightMargin = dp(70);
        root.addView(emptyHint, hintLp);
        emptyHint.setVisibility(View.GONE);

        infoOverlay = text("", 17, Color.WHITE);
        infoOverlay.setPadding(dp(18), dp(12), dp(18), dp(12));
        infoOverlay.setBackground(background(0xde101d30, 12));
        infoOverlay.setVisibility(View.GONE);
        FrameLayout.LayoutParams infoLp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        infoLp.leftMargin = dp(34);
        infoLp.topMargin = dp(30);
        root.addView(infoOverlay, infoLp);

        rtc = new RtcViewer(this, surface, new RtcViewer.Listener() {
            @Override public void onOffer(String offer) { startSession(offer); }
            @Override public void onStatus(String state) {
                if (active || !"已停止".equals(state)) status(state);
            }
        });
        applyVideoScale();

        // PAGE TWO: physically enters from below the screen when DOWN is pressed.
        settingsPage = new ScrollView(this);
        settingsPage.setFillViewport(true);
        settingsPage.setBackgroundColor(0xff0b1422);
        settingsPage.setVerticalScrollBarEnabled(false);
        settingsPage.setFocusable(false);
        settingsPage.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        root.addView(settingsPage, new FrameLayout.LayoutParams(-1, -1));
        settingsPage.setVisibility(View.INVISIBLE);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(52), dp(24), dp(52), dp(36));
        settingsPage.addView(content, new FrameLayout.LayoutParams(-1, -2));

        LinearLayout titleRow = row(content);
        TextView title = text("NestCam TV · 设置与控制", 27, Color.WHITE);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        TextView returnText = text("按返回键回到全屏探头  ↑", 16, 0xff9db4d0);
        returnText.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        titleRow.addView(returnText, new LinearLayout.LayoutParams(0, -1, 1));

        cameraName = text("未选择探头", 21, 0xffedf6ff);
        content.addView(cameraName, new LinearLayout.LayoutParams(-1, dp(37)));
        statusText = text("准备就绪", 15, 0xff9fbbd9);
        statusText.setMaxLines(2);
        content.addView(statusText, new LinearLayout.LayoutParams(-1, dp(50)));

        LinearLayout switchRow = row(content);
        firstSettingsButton = makeButton("◀ 上一个探头", switchRow, () -> changeCamera(-1));
        makeButton("下一个探头 ▶", switchRow, () -> changeCamera(1));

        LinearLayout playbackRow = row(content);
        makeButton("▶ 播放", playbackRow, this::play);
        makeButton("■ 停止", playbackRow, this::stop);
        makeButton("↻ 重连", playbackRow, () -> { stop(); play(); });
        makeButton("⟳ 刷新探头", playbackRow, () -> { stop(); refreshDevices(false); });

        LinearLayout pictureRow = row(content);
        Button pictureButton = makeButton("调整画面显示方式", pictureRow, this::toggleVideoScale);
        displayModeLabel = text("", 16, 0xff9fbbd9);
        displayModeLabel.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        pictureRow.addView(displayModeLabel, new LinearLayout.LayoutParams(0, -1, 1));
        updateDisplayModeLabel();

        TextView oauthTitle = text("Google Nest 授权 · 首次使用设置一次", 20, 0xffedf6ff);
        LinearLayout.LayoutParams oauthTitleParams = new LinearLayout.LayoutParams(-1, dp(50));
        oauthTitleParams.topMargin = dp(10);
        content.addView(oauthTitle, oauthTitleParams);

        LinearLayout authRow = row(content);
        configButton = makeButton("① OAuth 配置", authRow, this::configure);
        makeButton("② 手机扫码授权", authRow, this::showAuthorizationQr);
        makeButton("③ 输入回调 code", authRow, this::inputCode);
        makeButton("④ 清除本机授权", authRow, this::clearCredentials);

        TextView tip = text("首页快捷键：↓ 设置   ·   ←/→ 切换探头   ·   确认键显示信息   ·   返回键关闭设置", 15, 0xff839bb8);
        LinearLayout.LayoutParams tipParams = new LinearLayout.LayoutParams(-1, dp(48));
        tipParams.topMargin = dp(10);
        content.addView(tip, tipParams);

        // An INVISIBLE panel is not focusable: remote always starts on full-screen video.
        root.requestFocus();
        root.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, orr, ob) -> {
            if (!settingsOpen && settingsPage != null) settingsPage.setTranslationY(b - t);
        });
    }

    private void openSettings() {
        if (settingsOpen) return;
        settingsOpen = true;
        hideInfoOverlay();
        settingsPage.animate().cancel();
        settingsPage.setTranslationY(Math.max(root.getHeight(), getResources().getDisplayMetrics().heightPixels));
        settingsPage.setVisibility(View.VISIBLE);
        settingsPage.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        settingsPage.animate().translationY(0f).setDuration(240).start();
        settingsPage.postDelayed(() -> {
            if (!settingsOpen) return;
            if (!api.linked() && configButton != null) configButton.requestFocus();
            else if (firstSettingsButton != null) firstSettingsButton.requestFocus();
        }, 60);
    }

    private void closeSettings() {
        if (!settingsOpen) return;
        settingsOpen = false;
        settingsPage.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        root.requestFocus();
        settingsPage.animate().cancel();
        settingsPage.animate().translationY(root.getHeight()).setDuration(240).withEndAction(() -> {
            if (!settingsOpen) settingsPage.setVisibility(View.INVISIBLE);
        }).start();
    }

    private void applyVideoScale() {
        if (surface != null) surface.setScalingType(fillVideo
                ? RendererCommon.ScalingType.SCALE_ASPECT_FILL
                : RendererCommon.ScalingType.SCALE_ASPECT_FIT);
    }

    private void updateDisplayModeLabel() {
        if (displayModeLabel != null) displayModeLabel.setText(fillVideo
                ? "当前：铺满屏幕（可能裁剪边缘）" : "当前：完整画面（可能留黑边）");
    }

    private void toggleVideoScale() {
        fillVideo = !fillVideo;
        getPreferences(MODE_PRIVATE).edit().putBoolean("fill_video", fillVideo).apply();
        applyVideoScale();
        updateDisplayModeLabel();
    }

    private void status(String text) {
        ui.post(() -> { if (statusText != null) statusText.setText(text); });
    }

    private void updateCameraName() {
        if (cameraName == null) return;
        if (chosen >= 0 && chosen < cameras.size()) {
            cameraName.setText("●  " + cameras.get(chosen).name + "    (" + (chosen + 1) + " / " + cameras.size() + ")");
        } else cameraName.setText("尚未选择探头");
    }

    private void showHint(String value) {
        if (emptyHint != null) {
            emptyHint.setText(value);
            emptyHint.setVisibility(View.VISIBLE);
        }
    }

    private void showInfoOverlay() {
        if (infoOverlay == null || settingsOpen) return;
        if (hideInfo != null) ui.removeCallbacks(hideInfo);
        String title = chosen >= 0 && chosen < cameras.size() ? cameras.get(chosen).name : "尚未选择探头";
        String state = statusText == null ? "" : statusText.getText().toString();
        infoOverlay.setText(title + "\n" + state + "\n按 ↓ 打开设置  ·  ←/→ 切换探头");
        infoOverlay.setVisibility(View.VISIBLE);
        hideInfo = this::hideInfoOverlay;
        ui.postDelayed(hideInfo, 4200);
    }

    private void hideInfoOverlay() {
        if (hideInfo != null) ui.removeCallbacks(hideInfo);
        hideInfo = null;
        if (infoOverlay != null) infoOverlay.setVisibility(View.GONE);
    }

    private void loadCached() {
        JSONArray devices = api.cachedDevices();
        if (devices.length() > 0) applyDevices(devices, true);
        else if (!api.linked()) {
            status("首次使用：请按 ↓ 进入设置并授权 Google Nest");
            showHint("请按遥控器 ↓ 进入设置，完成 Google Nest 授权");
        } else showHint("正在获取 Nest 探头，请按 ↓ 查看设置");
    }

    private void applyDevices(JSONArray data, boolean cached) {
        ArrayList<Camera> next = new ArrayList<>();
        String remembered = api.preferredDevice();
        for (int i = 0; i < data.length(); i++) {
            JSONObject d = data.optJSONObject(i);
            if (d != null && NestApi.webrtc(d)) next.add(new Camera(NestApi.title(d), d.optString("name")));
        }
        String prev = chosen >= 0 && chosen < cameras.size() ? cameras.get(chosen).id : "";
        cameras.clear();
        cameras.addAll(next);
        chosen = cameras.isEmpty() ? -1 : 0;
        for (int i = 0; i < cameras.size(); i++) {
            if (cameras.get(i).id.equals(remembered)
                    || (remembered.isEmpty() && cameras.get(i).name.equalsIgnoreCase("backyard"))) {
                chosen = i;
                break;
            }
            if (cameras.get(i).id.equals(prev)) chosen = i;
        }
        updateCameraName();
        if (cameras.isEmpty()) {
            status("没有找到支持 WebRTC 的 Nest 探头");
            showHint("未发现支持 WebRTC 的 Nest 探头 · 按 ↓ 查看设置");
        } else status((cached ? "已恢复上次探头" : "已刷新探头列表") + " · " + cameras.size() + " 台");
    }

    private void refreshDevices(boolean autoStart) {
        if (refreshing) return;
        if (!api.linked()) {
            status("请先到设置中完成 Google Nest 授权");
            showHint("尚未授权，按 ↓ 进入设置");
            return;
        }
        refreshing = true;
        status("正在读取 Nest 摄像头...");
        io.execute(() -> {
            try {
                JSONArray found = api.devices();
                ui.post(() -> {
                    refreshing = false;
                    applyDevices(found, false);
                    if (autoStart && foreground && chosen >= 0) play();
                });
            } catch (Exception e) {
                ui.post(() -> {
                    refreshing = false;
                    status("读取摄像头失败：" + message(e));
                    showHint("读取 Nest 探头失败 · 按 ↓ 查看设置");
                });
            }
        });
    }

    private void play() {
        if (active) return;
        if (!api.linked()) {
            status("尚未授权 Google Nest");
            showHint("请按 ↓ 打开设置完成授权");
            return;
        }
        if (chosen < 0 || chosen >= cameras.size()) { refreshDevices(true); return; }
        active = true;
        generation++;
        Camera camera = cameras.get(chosen);
        api.rememberDevice(camera.id);
        showHint("连接 " + camera.name + " 中...");
        status("正在建立 WebRTC 实时直播...");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        rtc.start();
    }

    private void startSession(String offer) {
        if (!active || chosen < 0 || chosen >= cameras.size()) return;
        final long ticket = generation;
        final String device = cameras.get(chosen).id;
        status("正在获取 Nest WebRTC Answer...");
        io.execute(() -> {
            try {
                JSONObject answer = api.start(device, offer);
                String session = answer.optString("mediaSessionId");
                String sdp = answer.getString("answerSdp");
                String expires = answer.optString("expiresAt");
                ui.post(() -> {
                    if (!active || ticket != generation) {
                        if (!session.isEmpty()) io.execute(() -> {
                            try { api.stop(device, session); } catch (Exception ignored) { }
                        });
                        return;
                    }
                    mediaSession = session;
                    streamingDevice = device;
                    rtc.setAnswer(sdp);
                    emptyHint.setVisibility(View.GONE);
                    scheduleExtension(expires, ticket);
                    status("正在接收实时画面...");
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (!active || ticket != generation) return;
                    active = false;
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    rtc.stop();
                    showHint("直播连接失败 · 按 ↓ 进入设置并重连");
                    status("连接失败：" + message(e));
                });
            }
        });
    }

    private String message(Exception e) {
        String s = e.getMessage();
        return s == null || s.isEmpty() ? e.getClass().getSimpleName() : s;
    }

    private void scheduleExtension(String expiresAt, long ticket) {
        if (extension != null) ui.removeCallbacks(extension);
        if (mediaSession.isEmpty() || !active) return;
        long delay = 210000L;
        try { delay = Instant.parse(expiresAt).toEpochMilli() - System.currentTimeMillis() - 45000L; }
        catch (Exception ignored) { }
        delay = Math.min(240000L, Math.max(30000L, delay));
        extension = () -> {
            if (!active || ticket != generation) return;
            String device = streamingDevice, session = mediaSession;
            status("正在续期 Nest 直播...");
            io.execute(() -> {
                try {
                    JSONObject result = api.extend(device, session);
                    ui.post(() -> {
                        if (active && ticket == generation && session.equals(mediaSession)) {
                            scheduleExtension(result.optString("expiresAt"), ticket);
                            status("实时直播中");
                        }
                    });
                } catch (Exception e) {
                    ui.post(() -> {
                        if (!active || ticket != generation) return;
                        status("续期失败，请重连：" + message(e));
                        stop();
                    });
                }
            });
        };
        ui.postDelayed(extension, delay);
    }

    private void stop() {
        generation++;
        active = false;
        if (extension != null) ui.removeCallbacks(extension);
        extension = null;
        String oldSession = mediaSession, device = streamingDevice;
        mediaSession = "";
        streamingDevice = "";
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (rtc != null) rtc.stop();
        showHint("直播已停止 · 按 ↓ 进入设置重新播放");
        if (!oldSession.isEmpty()) io.execute(() -> {
            try { api.stop(device, oldSession); } catch (Exception ignored) { }
        });
    }

    private void changeCamera(int direction) {
        if (cameras.isEmpty()) { refreshDevices(false); return; }
        stop();
        chosen = (chosen + direction + cameras.size()) % cameras.size();
        updateCameraName();
        api.rememberDevice(cameras.get(chosen).id);
        play();
        if (!settingsOpen) showInfoOverlay();
    }

    private void field(String title, boolean password, String initial, Consumer<String> done) {
        EditText edit = new EditText(this);
        edit.setText(initial);
        edit.setTextColor(Color.WHITE);
        edit.setTextSize(19);
        edit.setSingleLine(true);
        edit.setSelectAllOnFocus(true);
        edit.setInputType(InputType.TYPE_CLASS_TEXT | (password
                ? InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD));
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(28), dp(6), dp(28), dp(8));
        box.addView(edit, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle(title).setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", (d, w) -> done.accept(edit.getText().toString().trim()))
                .show();
    }

    private void configure() {
        field("OAuth Client ID（可用手机遥控器输入）", false, api.clientId(), id ->
                field("OAuth Client Secret（只保存在电视本地）", true, "", secret -> {
                    try {
                        api.configure(id, secret);
                        status("OAuth 已配置，请继续扫码授权");
                    } catch (Exception e) { status("配置失败：" + message(e)); }
                }));
    }

    private void showAuthorizationQr() {
        String url;
        try { url = api.authorizationUrl(); }
        catch (Exception e) { status(message(e)); return; }
        try {
            BitMatrix matrix = new MultiFormatWriter().encode(url, BarcodeFormat.QR_CODE, 460, 460);
            Bitmap bmp = Bitmap.createBitmap(matrix.getWidth(), matrix.getHeight(), Bitmap.Config.ARGB_8888);
            for (int y = 0; y < matrix.getHeight(); y++) {
                for (int x = 0; x < matrix.getWidth(); x++) {
                    bmp.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            ImageView qr = new ImageView(this);
            qr.setImageBitmap(bmp);
            qr.setBackgroundColor(Color.WHITE);
            qr.setPadding(dp(8), dp(8), dp(8), dp(8));
            LinearLayout body = new LinearLayout(this);
            body.setGravity(Gravity.CENTER);
            body.setOrientation(LinearLayout.VERTICAL);
            body.setPadding(dp(24), dp(14), dp(24), dp(12));
            body.addView(qr, new LinearLayout.LayoutParams(dp(280), dp(280)));
            TextView help = text("用手机扫描二维码完成 Google Nest 授权，复制最后跳转的网址（包含 code=），再在电视设置中输入。", 16, Color.WHITE);
            help.setGravity(Gravity.CENTER);
            help.setPadding(0, dp(12), 0, 0);
            body.addView(help, new LinearLayout.LayoutParams(dp(590), -2));
            new AlertDialog.Builder(this).setTitle("手机扫码授权 Google Nest")
                    .setView(body).setPositiveButton("关闭", null).show();
        } catch (Exception e) { status("二维码生成失败：" + message(e)); }
    }

    private void inputCode() {
        field("输入回调网址（含 code=）或授权 code", false, "", code -> {
            status("正在验证 Google 授权...");
            io.execute(() -> {
                try {
                    api.exchange(code);
                    ui.post(() -> { status("授权成功，正在读取探头..."); refreshDevices(true); });
                } catch (Exception e) { status("授权失败：" + message(e)); }
            });
        });
    }

    private void clearCredentials() {
        new AlertDialog.Builder(this).setTitle("清除电视本机的 Nest 授权？")
                .setMessage("会清除电视中保存的 OAuth 配置、授权令牌及探头缓存，不影响手机和手表。")
                .setNegativeButton("取消", null)
                .setPositiveButton("清除", (d, w) -> {
                    stop();
                    api.clear();
                    cameras.clear();
                    chosen = -1;
                    updateCameraName();
                    showHint("请按 ↓ 进入设置并重新授权 Google Nest");
                    status("电视端授权信息已清除");
                    if (settingsOpen) configButton.requestFocus();
                }).show();
    }

    @Override protected void onResume() {
        super.onResume();
        foreground = true;
        fullScreen();
        ui.postDelayed(() -> {
            if (!foreground || active || !api.linked()) return;
            if (chosen >= 0) play(); else refreshDevices(true);
        }, 350);
    }

    @Override protected void onPause() {
        foreground = false;
        stop();
        super.onPause();
    }

    // Dispatch before the focused widget sees remote DPAD events.
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            int key = event.getKeyCode();
            if (key == KeyEvent.KEYCODE_MEDIA_PLAY || key == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
                if (active) stop(); else play();
                return true;
            }
            if (key == KeyEvent.KEYCODE_MEDIA_STOP) { stop(); return true; }
            if (!settingsOpen) {
                if (key == KeyEvent.KEYCODE_DPAD_DOWN || key == KeyEvent.KEYCODE_MENU) {
                    openSettings(); return true;
                }
                if (key == KeyEvent.KEYCODE_DPAD_LEFT) { changeCamera(-1); return true; }
                if (key == KeyEvent.KEYCODE_DPAD_RIGHT) { changeCamera(1); return true; }
                if (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER) {
                    showInfoOverlay(); return true;
                }
            } else {
                if (key == KeyEvent.KEYCODE_BACK || key == KeyEvent.KEYCODE_ESCAPE
                        || key == KeyEvent.KEYCODE_MENU) {
                    closeSettings(); return true;
                }
                if (key == KeyEvent.KEYCODE_DPAD_UP && getCurrentFocus() == firstSettingsButton) {
                    closeSettings(); return true;
                }
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override protected void onDestroy() {
        stop();
        hideInfoOverlay();
        if (rtc != null) rtc.release();
        io.shutdown();
        super.onDestroy();
    }
}
